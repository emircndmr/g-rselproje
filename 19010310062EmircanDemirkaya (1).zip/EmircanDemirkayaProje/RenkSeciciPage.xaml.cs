namespace Emircandemirkaya
{
    public partial class RenkSeciciPage : ContentPage
    {
        public RenkSeciciPage()
        {
            InitializeComponent();
        }

        private void Slider_ValueChanged(object sender, ValueChangedEventArgs e)
        {
            UpdateColorDisplay();
        }

        private void UpdateColorDisplay()
        {
            int red = (int)RedSlider.Value;
            int green = (int)GreenSlider.Value;
            int blue = (int)BlueSlider.Value;

            ColorCodeLabel.Text = $"#{red:X2}{green:X2}{blue:X2}";
        }
    }
}
